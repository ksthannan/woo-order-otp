<?php

namespace MessageBird\Exceptions;

class ValidationException extends MessageBirdException
{
}
