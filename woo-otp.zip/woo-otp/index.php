<?php 
// Silence is golden

